// homeproduct.js;

const Homeproduct = [
  {
    id: 1,
    Title: 'Galaxy Tab S6 Lite 10.4-inch Android Tablet 128GB.',
    Cat: 'Tablet',
    Price: '$723',
    Img: './assets/tp1.jpg',
  },
  {
    id: 2,
    Title: 'Tracker with IP67 Waterproof Pedometer Smart watch.',
    Cat: 'Smart Watch',
    Price: '$168',
    Img: './assets/tp2.jpg',
  },
  {
    id: 3,
    Title: 'Cancelling Headphones Wireless.',
    Cat: 'Headphone',
    Price: '$49',
    Img: './assets/tp3.jpg',
  },
  {
    id: 4,
    Title: 'Professional Camera 4K Digital Video Camera.',
    Cat: 'Camera',
    Price: '$1049',
    Img: './assets/tp4.jpg',
  },
  {
    id: 5,
    Title: 'Mini Portable PD 22.5W Fast Charging Powerbank.',
    Cat: 'Powerbank',
    Price: '$49',
    Img: './assets/tp5.jpg',
  },
  {
    id: 6,
    Title: 'CPU Cooler 2 Heat Pipes 12mm 4 Pin PWM RGB for Intel.',
    Cat: 'Heat pipe',
    Price: '$156',
    Img: './assets/tp6.png',
  },
  {
    id: 7,
    Title: 'Playstation 4 2TB Slim Gaming Console.',
    Cat: 'Gaming',
    Price: '$2098',
    Img: './assets/tp7.jpg',
  },
  {
    id: 8,
    Title: 'Mini Portable Mobile Phone Powerbank for iphone.',
    Cat: 'Powerbank',
    Price: '$386',
    Img: './assets/tp8.jpg',
  },
];
export default Homeproduct;
